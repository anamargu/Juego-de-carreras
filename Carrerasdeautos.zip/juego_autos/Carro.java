import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class obstaculo here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Carro extends Actor
{
    private int speed;
    public Carro (int velocidad){
        speed = velocidad;

    }
    /**
     * Act - do whatever the obstaculo wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        if(Greenfoot.isKeyDown("right")){
            if ( getX() < 360)
            setLocation (getX () + speed, getY());
        }
        if(Greenfoot.isKeyDown("left")){
             if ( getX() > 55)
            setLocation (getX () - speed, getY());
            
            
        }
        if(Greenfoot.isKeyDown("up")){
             if ( getY() > 100)
            setLocation (getX () , getY() - speed );
            
        }
        if(Greenfoot.isKeyDown("down")){
             if ( getY() < 540)
            setLocation (getX () , getY() + speed );
            
        }
        if (isTouching(obstaculo.class)) {

            Greenfoot.stop();
        }
    }
    public void checkCollision(){
        Actor collided = getOneIntersectingObject (obstaculo.class);
        if (collided  != null ){
            getWorld ().removeObject (this);
            Greenfoot.stop();
 
 
        }
}
    public void aumenta_velocidad(){
        speed++;
        
    }
}
